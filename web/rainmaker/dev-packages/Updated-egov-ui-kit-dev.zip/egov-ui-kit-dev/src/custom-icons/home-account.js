import React from "react";
import SvgIcon from "material-ui/SvgIcon";

const HomeAccount = (props) => {
  return (
    <SvgIcon viewBox="0 0 24 24" className="custom-icon" {...props}>
      <path d="M12,3L2,12H5V20H19V12H22L12,3M12,8.75A2.25,2.25 0 0,1 14.25,11A2.25,2.25 0 0,1 12,13.25A2.25,2.25 0 0,1 9.75,11A2.25,2.25 0 0,1 12,8.75M12,15C13.5,15 16.5,15.75 16.5,17.25V18H7.5V17.25C7.5,15.75 10.5,15 12,15Z" />
    </SvgIcon>
  );
};

export default HomeAccount;
