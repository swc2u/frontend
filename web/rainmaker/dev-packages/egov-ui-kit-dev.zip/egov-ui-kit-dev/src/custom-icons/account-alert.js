import React from "react";
import SvgIcon from "material-ui/SvgIcon";

const AccountAlert = (props) => {
  return (
    <SvgIcon className="custom-icon" viewBox="0 0 24 24" {...props}>
      <path d="M10,4A4,4 0 0,1 14,8A4,4 0 0,1 10,12A4,4 0 0,1 6,8A4,4 0 0,1 10,4M10,14C14.42,14 18,15.79 18,18V20H2V18C2,15.79 5.58,14 10,14M20,12V7H22V12H20M20,16V14H22V16H20Z" />
    </SvgIcon>
  );
};

export default AccountAlert;
