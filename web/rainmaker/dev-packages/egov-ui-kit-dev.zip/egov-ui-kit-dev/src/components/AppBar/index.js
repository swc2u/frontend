import React from "react";
import AppBar from "material-ui/AppBar";

const AppBarUi = (props) => {
  return <AppBar {...props} />;
};

export default AppBarUi;

AppBarUi.propTypes = {};
