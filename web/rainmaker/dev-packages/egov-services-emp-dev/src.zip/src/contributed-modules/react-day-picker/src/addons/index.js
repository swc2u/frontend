// Deprecated: remove from the next major version!
export LocaleUtils from './LocaleUtils';
