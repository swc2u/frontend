export { MomentLocalUtils as default } from './addons/MomentLocaleUtils';
