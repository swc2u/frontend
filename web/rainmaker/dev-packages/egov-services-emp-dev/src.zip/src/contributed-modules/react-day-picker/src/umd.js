// Entry point for the umd package
const DayPicker = require('./DayPicker').default;
DayPicker.Input = require('./DayPickerInput').default;

export default DayPicker;
